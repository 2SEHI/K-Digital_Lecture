package com.example.firstapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    // 메인 화면에 만들어진 View를 위한 변수
    TextView tv_target;
    // 용도가 다른 변수는 한줄에 선언하면 안됩니다.
    Button btn_blue, btn_red;


    // 화면을 만들 때 호출되는 함수
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // res/layout/activity_main.xml 파일의 내용을 불러서
        // 화면을 설정하는 코드
        setContentView(R.layout.activity_main);
        // View들을 찾아옵니다
        tv_target = (TextView)findViewById(R.id.tv_target);
        btn_blue = (Button)findViewById(R.id.btn_blue);
        btn_red = (Button)findViewById(R.id.btn_red);

        // setText : 해당 속성의 텍스트를 변경
        tv_target.setText("Android");
        tv_target.setTextSize(30);

        // setOnLongClickListener()는 길게 Click할 경우
        // btn_blue 버튼에 이벤트 처리 추가
        btn_blue.setOnClickListener(
            new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    // tv_target의 글씨체를 blue로 변경
                    tv_target.setTextColor(Color.BLUE);
                    // tv_target의 바탕을 red로 변경
                    tv_target.setBackgroundColor(Color.RED);
                }
            }
        );

        btn_red.setOnClickListener(
                new View.OnClickListener(){

                    @Override
                    public void onClick(View view) {
                        tv_target.setTextColor(Color.RED);
                        tv_target.setBackgroundColor(Color.BLUE);
                    }
                }
        );
    }


}